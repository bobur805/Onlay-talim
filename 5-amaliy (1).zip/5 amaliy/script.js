// Hamburger menyu uchun toggle
const menuToggle = document.getElementById("menu-toggle");
const dropdownMenu = document.getElementById("dropdown-menu");

menuToggle.addEventListener("click", () => {
  dropdownMenu.classList.toggle("hidden");
});

// Modal oynani boshqarish
const modal = document.getElementById("modal");
const modalBody = document.getElementById("modal-body");

function showInfo(type) {
  let content = "";
  if (type === "tolov") {
    content = `<h3 id="modal-title">To‘lov haqida</h3>
      <p>Bizning kurslarimiz arzon va sifatli ta’limni ta’minlaydi. To‘lovlar bank orqali amalga oshiriladi.</p>`;
  } else if (type === "fikr") {
    content = `<h3 id="modal-title">Fikr bildirish</h3>
      <p>Iltimos, bizning xizmatlarimiz haqida fikr-mulohazalaringizni bildiring.</p>`;
  }
  modalBody.innerHTML = content;
  modal.classList.remove("hidden");
}

function closeModal() {
  modal.classList.add("hidden");
}

// Video darslar ma’lumotlari
const videos = {
  matematika: [
    "https://www.youtube.com/embed/DuLr0MpNTMw",
    "https://www.youtube.com/embed/IT8DUVcyGjE",
    "https://www.youtube.com/embed/GlafUwEwXXo",
    "https://www.youtube.com/embed/ySs67QdlNYU"
  ],
  "ona-tili": [
    "https://www.youtube.com/embed/07SOqxGmF84",
    "https://www.youtube.com/embed/rbtZXnLTlO0",
    "https://www.youtube.com/embed/hWVhIqiKigE",
    "https://www.youtube.com/embed/q9o1zN94N_g"
  ],
  "ingliz-tili": [
    "https://www.youtube.com/embed/-4uUT1dOF0w",
    "https://www.youtube.com/embed/jXRvqhDJrNY",
    "https://www.youtube.com/embed/KMyV7SfYzrM",
    "https://www.youtube.com/embed/9GyJr-nF7Wc"
  ]
};

// Video bo‘limi elementlari
const videoSection = document.getElementById("video-section");
const videoList = document.getElementById("video-list");
const welcomeMessage = document.getElementById("welcome-message");

// Ro‘yxatdan o‘tish formasi
const registrationForm = document.getElementById("registration-form");

registrationForm.addEventListener("submit", function (e) {
  e.preventDefault();

  const ism = this.ism.value.trim();
  const kurs = this.kurs.value;

  if (!ism) {
    alert("Iltimos, ismingizni kiriting!");
    return;
  }

  // Boshqa asosiy elementlarni yashirish
  document.querySelector("header").classList.add("hidden");
  document.getElementById("kurslar").classList.add("hidden");
  document.getElementById("royhatdan_otish").classList.add("hidden");
  document.getElementById("boglanish").classList.add("hidden");
  document.querySelector("footer").classList.add("hidden");
  const aside = document.querySelector("aside");
  if (aside) aside.classList.add("hidden");

  // Video bo‘limini ko‘rsatish
  videoSection.classList.remove("hidden");
  welcomeMessage.textContent = `${ism}, Boshlang'ich ta'lim kurslariga xush kelibsiz!`;
  welcomeMessage.classList.remove("hidden");

  // Video darslarini yuklash
  loadVideosByCourse(kurs);
});

function loadVideosByCourse(kurs) {
  videoList.innerHTML = ""; // avvalgi videolarni tozalash
  if (!videos[kurs]) return;

  videos[kurs].forEach((videoUrl) => {
    const iframe = document.createElement("iframe");
    iframe.src = videoUrl;
    iframe.allow =
      "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture";
    iframe.allowFullscreen = true;
    iframe.title = "Video dars";

    videoList.appendChild(iframe);
  });
}